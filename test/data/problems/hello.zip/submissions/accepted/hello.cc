#include <cstdio>

int main(void) {
  printf("Hello World!\n");
  return 0;
}
