#!/usr/bin/python3
n, k = map(int, input().strip().split())
tlen, ocnt = [1], [0]
while tlen[-1] < n and len(tlen) <= k:
    tlen.append(k * tlen[-1] + 1)
    ocnt.append(k * ocnt[-1] + 1)
if len(tlen) == k + 1 and tlen[-1] <= n:
    print(ocnt[-1] + n - tlen[-1])
    exit(0)
ones = 0
while len(tlen) > 1:
    if n == tlen[-1]:
        ones += 1
        n -= 1
    ones += (n // tlen[-2]) * ocnt[-2]
    n %= tlen[-2]
    tlen.pop()
    ocnt.pop()
print(ones)
