#![allow(non_snake_case)]

use std::io::{stdin, BufRead};

struct S {
    K: u64,
    cache: Vec<(u64, u64)>,
}

impl S {
    fn solve(N: u64, K: u64) -> u64 {
        let mut s = Self {
            K,
            cache: Default::default(),
        };

        for level in 1..K {
            let (ones, total) = s.calc(N, level);
            if total >= N {
                return ones;
            }
        }

        let (ones, total) = s.calc(N, K);
        let remaining = N - total;
        return ones + remaining;
    }

    fn calc(&mut self, mut N: u64, level: u64) -> (u64, u64) {
        if N == 0 {
            return (0, 0);
        }

        if level == 1 {
            return (0, self.K);
        }

        if let Some((ones, total)) = self.cache.get(level as usize) {
            if *total <= N {
                return (*ones, *total);
            }
        }

        let orig_N = N;
        let mut total_ones = 0;
        let mut total_total = 0;

        for _ in 0..self.K {
            let (ones, total) = self.calc(N, level - 1);
            N = N.saturating_sub(total);
            total_ones += ones;
            total_total += total;

            if N == 0 {
                return (total_ones, orig_N);
            }

            N -= 1;
            total_ones += 1;
            total_total += 1;
        }

        self.cache.resize((level + 1) as usize, (0, u64::MAX));
        self.cache[level as usize] = (total_ones, total_total);
        return (total_ones, total_total);
    }
}

fn main() {
    let mut stdin = stdin().lock();
    let mut line = String::new();
    stdin.read_line(&mut line).unwrap();
    let parts: Vec<u64> = line
        .split_whitespace()
        .map(|s| s.parse().unwrap())
        .collect();
    let N = parts[0];
    let K = parts[1];

    let res = S::solve(N, K);
    println!("{}", res);
}
