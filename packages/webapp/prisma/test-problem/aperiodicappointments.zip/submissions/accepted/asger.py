#!/usr/bin/env python3
from typing import Tuple


cache = [None, None]
K = -1

def calc(N: int, level: int) -> Tuple[int, int]:
    if N <= 0:
        return 0, 0

    if level == 1:
        return 0, K

    if level < len(cache):
        total_ones, total = cache[level]
        if total <= N:
            return total_ones, total

    orig_N = N
    total_ones = 0
    total_total = 0
    for _ in range(K):
        ones, total = calc(N, level - 1)
        N -= total
        total_ones += ones
        total_total += total

        if N <= 0:
            return total_ones, orig_N

        N -= 1
        total_ones += 1
        total_total += 1
    
    # assert len(cache) == level
    cache.append((total_ones, total_total))
    return total_ones, total_total


N, K = map(int, input().split())

for level in range(1, K):
    ones, total = calc(N, level)
    if total >= N:
        print(ones)
        exit()

ones, total = calc(N, K)
remaining = N - total
print(ones + remaining)
