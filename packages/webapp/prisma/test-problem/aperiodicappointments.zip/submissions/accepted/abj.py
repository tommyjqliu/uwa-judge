#!/usr/bin/env python2
N,K=map(int,raw_input().split())
sm=0
while N:
  rng=1
  rep=1
  ant=0
  while rng*K+1<=N:
    rng=rng*K+1
    ant=ant*K+1
    if rng*K+1<=N: rep+=1
    if rep==K:
      break
  q=min(K,N//rng)
  sm+=ant*q
  N-=q*rng
  if rep==K:
    sm+=N
    N=0
print(sm)
  

