#include <bits/stdc++.h>
using namespace std;
 
#define rep(i, a, b) for(int i = a; i < (b); ++i)
#define trav(a, x) for(auto& a : x)
#define all(x) x.begin(), x.end()
#define sz(x) (int)(x).size()
typedef long long ll;
typedef pair<int, int> pii;
typedef pair<ll, ll> pll;
typedef vector<int> vi;
typedef vector<ll> vl;

 
const ll MAXN = 1000000007;

ll solve(ll n, ll k){
    if(n <= k)return 0;
    ll f = k+1;
    ll power = 1;
    while(f <= n){
        if(f*k+1 > n)break;
        f = f*k+1;
        power++;
        if(power == k)break;
    }
    ll ones = (f-1)/k;
    if(power == k)return ones + n-f;

    ll d = n / f;
    return ones*d + solve(n%f, k);
}

int main() {
    ios_base::sync_with_stdio(0);
    cin.tie(0);
 
    ll n,k;

    cin >> n >> k;

    cout << solve(n,k) << "\n";
    
    return 0;
}