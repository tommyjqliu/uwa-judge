#include "validator.h"

using namespace std;

void run() {
  int n = Int(1, 1000000000);
  Space();
  int k = Int(2, 1000000000);
  Endl();
}
