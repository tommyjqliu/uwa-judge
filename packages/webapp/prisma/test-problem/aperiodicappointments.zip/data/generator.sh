#!/bin/bash
USE_SCORING=0
. ../../../testdata_tools/gen.sh

# ulimit -s unlimited

use_solution nils.cpp

compile gen_random.py

sample_manual 1
sample_manual 2

tc small-01 gen_random n=1 k=2
tc small-02 gen_random n=3 k=2
tc small-03 gen_random n=5 k=2
tc small-04 gen_random n=6 k=2
tc small-05 gen_random n=8 k=2
tc small-06 gen_random n=9 k=2
tc small-07 gen_random n=20 k=2
tc small-08 gen_random n=10 k=3
tc small-09 gen_random n=38 k=3
tc small-10 gen_random n=39 k=3
tc small-11 gen_random n=77 k=3
tc small-12 gen_random n=100 k=4
tc small-13 gen_random n=340 k=4
tc small-14 gen_random n=111 k=5
tc small-15 gen_random n=421 k=5
tc small-16 gen_random n=500 k=7

tc medium-01 gen_random n=3905 k=5
tc medium-02 gen_random n=3906 k=5
tc medium-03 gen_random n=5000 k=5
tc medium-04 gen_random n=10000 k=6
tc medium-05 gen_random n=30201 k=9
tc medium-06 gen_random n=60212 k=10
tc medium-07 gen_random n=145961 k=11
tc medium-08 gen_random n=331132 k=23
tc medium-09 gen_random n=960801 k=7

tc large-01 gen_random n=1000000000 k=2
tc large-02 gen_random n=1000000000 k=10
tc large-03 gen_random n=1000000000 k=19
tc large-04 gen_random n=1000000000 k=71
tc large-05 gen_random n=1000000000 k=5121
tc large-06 gen_random n=1000000000 k=23114
tc large-07 gen_random n=1000000000 k=45112
tc large-08 gen_random n=1000000000 k=151234
tc large-09 gen_random n=1000000000 k=567122
tc large-10 gen_random n=1000000000 k=1231293
tc large-11 gen_random n=1000000000 k=7294815
tc large-12 gen_random n=1000000000 k=41501223
tc large-13 gen_random n=1000000000 k=100231345
tc large-14 gen_random n=1000000000 k=412312311
tc large-15 gen_random n=1000000000 k=999912381
tc large-16 gen_random n=1000000000 k=1000000000

