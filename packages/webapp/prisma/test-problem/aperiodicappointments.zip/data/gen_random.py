#!/usr/bin/python3

import sys
import random

default = {
    "n": -1,
    "k": 10,
}

def cmdlinearg(name):
    for arg in sys.argv:
        if arg.startswith(name + "="):
            return arg.split("=")[1]
    return default[name]

def main():

    random.seed(int(sys.argv[-1]))
    n = int(cmdlinearg("n"))
    k = int(cmdlinearg("k"))
    MAXT = 10**9

    if n == -1:
        n = random.randint(1, 1000)
        if random.randint(0,1) == 1:
            k = random.randint(2,10)
        else:
            k = random.randint(11,1000)

    print(n,k)
    
    
if __name__ == "__main__":
    main()
