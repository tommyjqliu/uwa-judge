/*
 * Sample solution in C for the "boolfind" interactive problem.
 * Exits immediately without any output.
 *
 * @EXPECTED_RESULTS@: WRONG-ANSWER
 */

int main()
{
	return 0;
}
