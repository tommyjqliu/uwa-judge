/*
 * This should fail submission because of multiple @EXPECTED_RESULTS@ tags.
 *
 * @EXPECTED_RESULTS@: CORRECT, NO-OUTPUT
 *
 */

int main()
{
	return 0;
}
