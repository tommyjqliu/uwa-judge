/*
 * This should fail with RUN-ERROR (due to exitcode != 0)
 *
 * @EXPECTED_RESULTS@: RUN-ERROR
 */

int main()
{
	return 1;
}
