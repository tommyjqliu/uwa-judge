/*
 * This should fail with NO-OUTPUT.
 * The EXPECTED_RESULT tag in expected_result.txt file should be used.
 *
 */

int main()
{
	return 0;
}
