# @EXPECTED_RESULTS@: COMPILER-ERROR

This is not correct Perl syntax and will give errors!
