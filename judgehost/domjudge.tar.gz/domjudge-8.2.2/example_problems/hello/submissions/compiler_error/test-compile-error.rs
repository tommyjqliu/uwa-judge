/*
 * This should fail with a COMPILER-ERROR
 *
 * @EXPECTED_RESULTS@: COMPILER-ERROR
 */

This is not correct rust-syntax and will give compilation errors!
