--[[
 - This should give COMPILER-ERROR using syntax checking.
 -
 - @EXPECTED_RESULTS@: COMPILER-ERROR
--]]

this is not valid Lua syntax!


