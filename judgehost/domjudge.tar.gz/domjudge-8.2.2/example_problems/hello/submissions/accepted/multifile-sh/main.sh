# This multifile submission should give CORRECT on the default problem 'hello'.
#
# @EXPECTED_RESULTS@: CORRECT

# Use explicit path, since "." may not be included in PATH
. ./secondary.sh

exit 0
