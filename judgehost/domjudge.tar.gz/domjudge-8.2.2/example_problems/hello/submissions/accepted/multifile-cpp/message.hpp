#include <string>

class message {
private:
	std::string data;

public:
	message();
	void print();
};
