/*
 * This should give a TIMELIMIT.
 *
 * @EXPECTED_RESULTS@: TIMELIMIT
 */

int main()
{
	int a = 0;

	while ( 1 ) a++;

	return 0;
}
