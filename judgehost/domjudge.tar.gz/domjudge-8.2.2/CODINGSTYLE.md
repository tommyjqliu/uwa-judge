DOMjudge project coding style guideline
=======================================

We follow the [PSR-2 coding style](https://www.php-fig.org/psr/psr-2/).
