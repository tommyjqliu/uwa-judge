/* Sample solution for the default "Demo Contest" problem "hello"
 * @EXPECTED_RESULTS@: CORRECT
 */

import java.io.*;

class Main
{
	public static void main(String[] args) throws IOException
	{
		System.out.println("Hello world!");
	}
}
