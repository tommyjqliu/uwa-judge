DOMjudge Manual
===============

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   overview
   install-domserver
   install-judgehost
   install-workstation
   upgrading
   config-basic
   import
   config-advanced
   running
   judging
   develop

Appendices
----------

.. toctree::
   quick-install
   team
   problem-format
   shadow
   configuration-reference
