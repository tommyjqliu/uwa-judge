#include <assert.h>
#include <stdio.h>

int main() {
  while (1) {
    int x;
    scanf("%d", &x);
  }
}
