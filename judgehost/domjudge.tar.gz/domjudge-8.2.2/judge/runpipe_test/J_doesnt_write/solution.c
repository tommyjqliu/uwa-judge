#include <assert.h>
#include <stdio.h>

int main() {
  int x;
  int s = scanf("%d", &x);
  return s;
}
